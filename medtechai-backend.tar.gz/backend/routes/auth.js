const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const router = express.Router();
const db = require('../utils/database');

// POST /api/auth/login
router.post('/login', async (req, res) => {
    try {
        const { username, password } = req.body;
        
        if (!username || !password) {
            return res.status(400).json({ error: 'Username and password required' });
        }
        
        const user = await db.findUser(username);
        
        if (!user) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        // Verify password with bcrypt
        const isValidPassword = await bcrypt.compare(password, user.password_hash);
        
        if (!isValidPassword) {
            return res.status(401).json({ error: 'Invalid credentials' });
        }
        
        const token = jwt.sign(
            { 
                userId: user.id, 
                username: user.username, 
                role: user.role,
                email: user.email
            },
            process.env.JWT_SECRET,
            { expiresIn: process.env.JWT_EXPIRE || '8h' }
        );
        
        // Log successful login
        await db.query(
            `INSERT INTO audit_log (user_id, action, table_name, ip_address)
             VALUES ($1, 'login', 'users', $2)`,
            [user.id, req.ip]
        );
        
        res.json({
            token,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                role: user.role,
                firstName: user.first_name,
                lastName: user.last_name,
                licenseNumber: user.license_number
            }
        });
    } catch (error) {
        console.error('Login error:', error);
        res.status(500).json({ error: 'Login failed' });
    }
});

// POST /api/auth/register
router.post('/register', async (req, res) => {
    try {
        const { username, email, password, role, firstName, lastName, licenseNumber, phone } = req.body;
        
        // Validation
        if (!username || !email || !password || !role || !firstName || !lastName) {
            return res.status(400).json({ error: 'All required fields must be provided' });
        }
        
        if (password.length < 8) {
            return res.status(400).json({ error: 'Password must be at least 8 characters' });
        }
        
        const validRoles = ['admin', 'pharmacist', 'doctor', 'patient'];
        if (!validRoles.includes(role)) {
            return res.status(400).json({ error: 'Invalid role' });
        }
        
        // Check if user already exists
        const existingUser = await db.findUser(username);
        if (existingUser) {
            return res.status(409).json({ error: 'Username already exists' });
        }
        
        // Check email
        const emailCheck = await db.query('SELECT id FROM users WHERE email = $1', [email]);
        if (emailCheck.rows.length > 0) {
            return res.status(409).json({ error: 'Email already registered' });
        }
        
        // Create user
        const newUser = await db.createUser({
            username,
            email,
            password,
            role,
            firstName,
            lastName,
            licenseNumber,
            phone
        });
        
        // If patient, create patient record
        if (role === 'patient') {
            await db.query(
                `INSERT INTO patients (user_id, date_of_birth, gender) 
                 VALUES ($1, '1990-01-01', 'other')`,
                [newUser.id]
            );
        }
        
        res.status(201).json({
            message: 'User created successfully',
            user: {
                id: newUser.id,
                username: newUser.username,
                email: newUser.email,
                role: newUser.role
            }
        });
    } catch (error) {
        console.error('Registration error:', error);
        res.status(500).json({ error: 'Registration failed' });
    }
});

// POST /api/auth/verify-token
router.post('/verify-token', async (req, res) => {
    try {
        const { token } = req.body;
        
        if (!token) {
            return res.status(400).json({ error: 'Token required' });
        }
        
        const decoded = jwt.verify(token, process.env.JWT_SECRET || 'change-this-in-production');
        
        // Check if user still exists and is active
        const user = await db.query('SELECT * FROM users WHERE id = $1 AND is_active = true', [decoded.userId]);
        
        if (user.rows.length === 0) {
            return res.status(401).json({ error: 'Invalid token' });
        }
        
        res.json({ valid: true, user: decoded });
    } catch (error) {
        res.status(401).json({ error: 'Invalid token' });
    }
});

// POST /api/auth/logout
router.post('/logout', (req, res) => {
    res.json({ message: 'Logged out successfully' });
});

module.exports = router;