require('dotenv').config();
const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const path = require('path');
// const logger = require('./utils/logger');

const app = express();
const PORT = process.env.PORT || 3000;

// Security middleware
app.use(helmet());
app.use(cors({
    origin: process.env.FRONTEND_URL || 'http://localhost:3000',
    credentials: true
}));

// Rate limiting
const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 100
});
app.use(limiter);

// Body parsing
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// Simple logging
app.use((req, res, next) => {
    console.log(`${req.method} ${req.url}`);
    next();
});

// API Routes
app.use('/api/auth', require('./routes/auth'));
app.use('/api/pharmacy', require('./routes/pharmacy'));
app.use('/api/consultations', require('./routes/consultations'));
app.use('/api/ai', require('./routes/ai'));
app.use('/api/fda', require('./routes/fda'));
app.use('/api/contact', require('./routes/contact'));
app.use('/api/services', require('./routes/services')); // إضافة مسار الخدمات الجديد

// Serve static files AFTER API routes
app.use(express.static(path.join(__dirname, '..', 'frontend')));

// Root health check for AWS
app.get('/', (req, res) => {
    res.status(200).json({
        status: 'OK',
        message: 'MedTechAI Backend API is running',
        timestamp: new Date().toISOString()
    });
});

// API health check
app.get('/api/health', (req, res) => {
    res.json({
        status: 'OK',
        timestamp: new Date().toISOString(),
        version: '1.0.0'
    });
});

// Serve frontend for SPA routes (HTML pages only)
app.get('*', (req, res) => {
    res.sendFile(path.join(__dirname, '../frontend/index.html'));
});

// Error handling
app.use((err, req, res, next) => {
    console.error(err.stack);
    res.status(500).json({ error: 'Internal server error' });
});

app.listen(PORT, '0.0.0.0', () => {
    console.log(`🚀 MedTechAI Backend running on port ${PORT}`);
});

process.on('uncaughtException', (err) => {
    console.error('Uncaught Exception:', err);
});