require('dotenv').config();
const { Pool } = require('pg');

const pool = new Pool({
    host: process.env.DB_HOST,
    port: process.env.DB_PORT,
    database: process.env.DB_NAME,
    user: process.env.DB_USER,
    password: process.env.DB_PASS,
    ssl: {
        require: true,
        rejectUnauthorized: false
    },
    connectionTimeoutMillis: 10000,
    idleTimeoutMillis: 30000
});

async function testConnection() {
    try {
        console.log('Testing AWS RDS PostgreSQL connection...');
        console.log('Host:', process.env.DB_HOST);
        console.log('Port:', process.env.DB_PORT);
        console.log('Database:', process.env.DB_NAME);
        console.log('User:', process.env.DB_USER);
        
        const client = await pool.connect();
        const result = await client.query('SELECT NOW()');
        console.log('✅ Connection successful!');
        console.log('Server time:', result.rows[0].now);
        client.release();
        process.exit(0);
    } catch (err) {
        console.error('❌ Connection failed:', err.message);
        console.error('Error code:', err.code);
        
        if (err.code === 'ETIMEDOUT') {
            console.log('\n🔧 Troubleshooting steps:');
            console.log('1. Check RDS Security Group allows inbound on port 5432');
            console.log('2. Verify your IP address is whitelisted');
            console.log('3. Ensure RDS is publicly accessible (if connecting from outside VPC)');
            console.log('4. Check if your firewall/antivirus blocks the connection');
        }
        process.exit(1);
    }
}

testConnection();