#!/usr/bin/env node

/**
 * MedTechAI Platform - Database Connection Test
 * This script tests database connectivity and configuration
 */

const fs = require('fs');
const path = require('path');

// Load environment variables
const rootEnvPath = path.resolve(__dirname, '../../.env');
require('dotenv').config({ path: rootEnvPath });

console.log('========================================');
console.log('MedTechAI Platform - Database Test');
console.log('========================================\n');

// Check if .env file exists
const envPath = rootEnvPath;
if (!fs.existsSync(envPath)) {
    console.log('❌ .env file not found at:', envPath);
    console.log('📝 Please create a .env file with your database configuration');
    console.log('\nExample .env content:');
    console.log('DATABASE_URL=postgresql://username:password@localhost:5432/medtechai');
    console.log('DB_HOST=localhost');
    console.log('DB_PORT=5432');
    console.log('DB_NAME=medtechai');
    console.log('DB_USER=your_username');
    console.log('DB_PASSWORD=your_password');
    process.exit(1);
}

console.log('✅ .env file found');

// Display current environment variables (without sensitive data)
console.log('\n📋 Database Configuration:');
console.log('- DATABASE_URL:', process.env.DATABASE_URL ? 'Set (details hidden)' : 'Not set');

if (!process.env.DATABASE_URL) {
    console.log('\n❌ Error: DATABASE_URL is not set. This is the required connection method for the application.');
    console.log('   Please ensure it is set in your .env file for the application to work correctly.');
    process.exit(1);
}


// Test database connection
async function testDatabaseConnection() {
    try {
        console.log('\n🔍 Testing database connection...');
        
        // Try to require pg module
        let pg;
        try {
            pg = require('pg');
            console.log('✅ PostgreSQL driver (pg) loaded successfully');
        } catch (error) {
            console.log('❌ PostgreSQL driver (pg) not found');
            console.log('💡 Run "npm install" in src/backend directory to install dependencies');
            return false;
        }

        console.log('🔗 Using DATABASE_URL for connection');

        // Create client
        const client = new pg.Client(process.env.DATABASE_URL);

        // Test connection
        console.log('🔌 Attempting to connect to database...');
        await client.connect();
        console.log('✅ Database connection successful!');

        // Test basic query
        console.log('📊 Testing basic query...');
        const result = await client.query('SELECT NOW() as current_time, version() as postgres_version');
        console.log('✅ Query executed successfully');
        console.log('⏰ Current time:', result.rows[0].current_time);
        console.log('🐘 PostgreSQL version:', result.rows[0].postgres_version.split(' ')[0]);

        // Test if tables exist
        console.log('\n🗃️  Checking database schema...');
        const tablesQuery = `
            SELECT table_name 
            FROM information_schema.tables 
            WHERE table_schema = 'public' 
            ORDER BY table_name;
        `;
        const tablesResult = await client.query(tablesQuery);
        
        if (tablesResult.rows.length > 0) {
            console.log('✅ Found existing tables:');
            tablesResult.rows.forEach(row => {
                console.log(`   - ${row.table_name}`);
            });
        } else {
            console.log('⚠️  No tables found in database');
            console.log('💡 Run database setup script to create tables');
        }

        await client.end();
        console.log('✅ Database connection closed');

        return true;

    } catch (error) {
        console.log('❌ Database connection failed:');
        console.log('   Error:', error.message);
        
        if (error.code === 'ECONNREFUSED') {
            console.log('\n💡 Troubleshooting tips:');
            console.log('   1. Is PostgreSQL installed and running? Check `services.msc` for a "postgresql" service or Task Manager for "postgres.exe".');
            console.log('   2. Is a firewall blocking the connection to the port specified in your DATABASE_URL? (Default is 5432)');
            console.log('   3. Is the host/port in your DATABASE_URL correct? For a local setup, it should be `localhost:5432`.');
        } else if (error.code === '28P01') {
            console.log('\n💡 Authentication failed:');
            console.log('   1. Double-check the username and password in your DATABASE_URL.');
            console.log('   2. Ensure the user role has connection permissions in PostgreSQL.');
        } else if (error.code === '3D000') {
            console.log('\n💡 Database does not exist:');
            console.log(`   1. The database specified in your DATABASE_URL was not found. You may need to create it first.`);
            console.log('      (Example: `CREATE DATABASE medtechai;`)');
            console.log('   2. Alternatively, run the setup script which might handle this for you: `node setup-db.js`');
        }

        return false;
    }
}

// Test server dependencies
async function testServerDependencies() {
    console.log('\n🔍 Testing server dependencies...');
    
    const requiredModules = [
        'express',
        'cors',
        'helmet',
        'bcryptjs',
        'jsonwebtoken',
        'dotenv',
        'express-rate-limit'
    ];

    let allDependenciesFound = true;

    for (const module of requiredModules) {
        try {
            require.resolve(module);
            console.log(`✅ ${module}`);
        } catch (error) {
            console.log(`❌ ${module} - Not found`);
            allDependenciesFound = false;
        }
    }

    if (!allDependenciesFound) {
        console.log('\n💡 Some dependencies are missing. Run "npm install" in src/backend directory');
    }

    return allDependenciesFound;
}

// Main execution
async function main() {
    const dependenciesOk = await testServerDependencies();
    const databaseOk = await testDatabaseConnection();

    console.log('\n========================================');
    console.log('Test Summary');
    console.log('========================================');
    console.log('Dependencies:', dependenciesOk ? '✅ OK' : '❌ FAILED');
    console.log('Database:', databaseOk ? '✅ OK' : '❌ FAILED');

    if (dependenciesOk && databaseOk) {
        console.log('\n🎉 All tests passed! Your environment is ready.');
        console.log('💡 You can now start the server with: npm run start');
    } else {
        console.log('\n⚠️  Some tests failed. Please fix the issues above.');
    }

    console.log('\n========================================');
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
    console.log('❌ Unhandled Rejection at:', promise, 'reason:', reason);
    process.exit(1);
});

// Run the tests
main().catch(error => {
    console.log('❌ Test script failed:', error.message);
    process.exit(1);
});