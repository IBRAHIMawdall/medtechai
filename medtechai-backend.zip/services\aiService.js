const medicalData = require('../data/medical-data');

class AIService {
  async analyzeMedicalImage(imageData, type) {
    return {
      confidence: 0.95,
      findings: ['Normal chest X-ray', 'No acute findings'],
      recommendations: ['Routine follow-up in 1 year']
    };
  }

  async analyzeLabResults(labResults) {
    const analysis = {
      summary: 'Comprehensive lab results analysis',
      findings: [],
      recommendations: [],
      criticalValues: []
    };
    
    if (labResults.results) {
      labResults.results.forEach(result => {
        const testName = result.name.toLowerCase();
        const range = medicalData.labReferenceRanges[testName];
        
        if (range) {
          const value = parseFloat(result.value);
          let status = 'normal';
          
          if (value < range.min) {
            status = 'low';
            analysis.findings.push({
              test: result.name,
              value: value,
              status: 'low',
              referenceRange: `${range.min}-${range.max} ${range.unit}`
            });
          } else if (value > range.max) {
            status = 'high';
            analysis.findings.push({
              test: result.name,
              value: value,
              status: 'high', 
              referenceRange: `${range.min}-${range.max} ${range.unit}`
            });
          }
          
          // Critical values check
          if ((range.critical_low && value < range.critical_low) || 
              (range.critical_high && value > range.critical_high)) {
            analysis.criticalValues.push({
              test: result.name,
              value: value,
              status: 'critical'
            });
          }
        }
      });
    }
    
    return analysis;
  }

  async checkDrugInteractions(medications) {
    const interactions = [];
    
    for (let i = 0; i < medications.length; i++) {
      for (let j = i + 1; j < medications.length; j++) {
        const drug1 = medications[i].toLowerCase();
        const drug2 = medications[j].toLowerCase();
        
        let interaction = null;
        if (medicalData.drugInteractions[drug1] && medicalData.drugInteractions[drug1][drug2]) {
          interaction = medicalData.drugInteractions[drug1][drug2];
        } else if (medicalData.drugInteractions[drug2] && medicalData.drugInteractions[drug2][drug1]) {
          interaction = medicalData.drugInteractions[drug2][drug1];
        }
        
        if (interaction) {
          interactions.push({
            drugs: [medications[i], medications[j]],
            severity: interaction.severity,
            description: interaction.description
          });
        }
      }
    }
    
    return interactions;
  }

  async predictRisk(patientData) {
    return {
      riskScore: 0.15,
      category: 'low',
      factors: ['age', 'BMI']
    };
  }

  async generateTreatmentPlan(patientData) {
    return {
      medications: [],
      dosages: [],
      duration: '30 days'
    };
  }
}

module.exports = new AIService();