const express = require('express');
const router = express.Router();
const aiService = require('../services/aiService');
// const logger = require('../utils/logger');

// POST /api/ai/analyze-lab-results
router.post('/analyze-lab-results', async (req, res) => {
    try {
        const { labResults } = req.body;
        
        if (!labResults || !labResults.results) {
            return res.status(400).json({ error: 'Lab results data required' });
        }

        const analysis = await aiService.analyzeLabResults(labResults);
        res.json(analysis);
    } catch (error) {
        console.error('Error analyzing lab results:', error);
        res.status(500).json({ error: 'Failed to analyze lab results' });
    }
});

// POST /api/ai/check-drug-interactions
router.post('/check-drug-interactions', async (req, res) => {
    try {
        const { medications } = req.body;
        
        if (!medications || !Array.isArray(medications)) {
            return res.status(400).json({ error: 'Medications array required' });
        }

        const interactions = await aiService.checkDrugInteractions(medications);
        res.json({ interactions });
    } catch (error) {
        console.error('Error checking drug interactions:', error);
        res.status(500).json({ error: 'Failed to check drug interactions' });
    }
});

// POST /api/ai/generate-recommendations
router.post('/generate-recommendations', async (req, res) => {
    try {
        const { patientData, labResults } = req.body;
        
        if (!patientData) {
            return res.status(400).json({ error: 'Patient data required' });
        }

        const recommendations = await aiService.generatePersonalizedRecommendations(patientData, labResults);
        res.json({ recommendations });
    } catch (error) {
        console.error('Error generating recommendations:', error);
        res.status(500).json({ error: 'Failed to generate recommendations' });
    }
});

// POST /api/ai/predict-trends
router.post('/predict-trends', async (req, res) => {
    try {
        const { historicalData } = req.body;
        
        if (!historicalData || !Array.isArray(historicalData)) {
            return res.status(400).json({ error: 'Historical data array required' });
        }

        const trends = await aiService.predictHealthTrends(historicalData);
        res.json({ trends });
    } catch (error) {
        console.error('Error predicting trends:', error);
        res.status(500).json({ error: 'Failed to predict health trends' });
    }
});

// POST /api/ai/virtual-assistant
router.post('/virtual-assistant', async (req, res) => {
    try {
        const { message, context } = req.body;
        
        if (!message) {
            return res.status(400).json({ error: 'Message required' });
        }

        // For now, we'll use a simple response system
        // In production, this would integrate with OpenAI for real AI responses
        const response = await generateVirtualAssistantResponse(message, context);
        res.json({ response });
    } catch (error) {
        console.error('Error processing virtual assistant request:', error);
        res.status(500).json({ error: 'Failed to process request' });
    }
});

// Helper function for virtual assistant responses
async function generateVirtualAssistantResponse(message, context) {
    const lowerMessage = message.toLowerCase();
    
    // Enhanced response system with more medical knowledge
    if (lowerMessage.includes('headache') || lowerMessage.includes('head pain')) {
        return {
            response: "For headaches, I can help you understand the symptoms:\n\n🔍 Common causes:\n• Tension headaches (most common)\n• Migraine\n• Sinus pressure\n• Dehydration\n• Stress or fatigue\n\n⚠️ Seek immediate medical attention if you have:\n• Sudden, severe headache (thunderclap)\n• Headache with fever and neck stiffness\n• Headache after head injury\n• Changes in vision or speech\n\n💡 General recommendations:\n• Stay hydrated\n• Get adequate sleep\n• Manage stress\n• Consider over-the-counter pain relief\n• Apply cold or warm compress",
            confidence: 0.9,
            followUp: "Would you like me to help you track your headache patterns or schedule a consultation?"
        };
    }
    
    if (lowerMessage.includes('fever') || lowerMessage.includes('temperature')) {
        return {
            response: "Fever is your body's natural response to infection or illness:\n\n🌡️ Temperature guidelines:\n• Normal: 98.6°F (37°C)\n• Low-grade fever: 99-100.4°F\n• Moderate fever: 100.4-102.2°F\n• High fever: 102.2-104°F\n• Very high fever: Above 104°F\n\n⚠️ Seek medical attention for:\n• Fever above 103°F in adults\n• Fever lasting more than 3 days\n• Fever with severe symptoms\n• Fever in infants under 3 months\n\n💡 Home care:\n• Stay hydrated\n• Rest\n• Use fever-reducing medications as directed\n• Cool compress or lukewarm bath",
            confidence: 0.9,
            followUp: "Are you experiencing any other symptoms along with the fever?"
        };
    }
    
    if (lowerMessage.includes('medication') || lowerMessage.includes('drug') || lowerMessage.includes('prescription')) {
        return {
            response: "I can help with medication-related questions:\n\n💊 Important reminders:\n• Take medications as prescribed\n• Don't skip doses without doctor approval\n• Store medications properly\n• Keep an updated medication list\n• Be aware of side effects\n\n⚠️ Drug interactions to watch for:\n• Over-the-counter medications\n• Herbal supplements\n• Alcohol consumption\n• Food interactions\n\n✅ Best practices:\n• Use one pharmacy for all prescriptions\n• Keep medications in original containers\n• Don't share medications\n• Dispose of expired medications properly",
            confidence: 0.8,
            followUp: "Do you have specific questions about any medications you're taking?"
        };
    }
    
    if (lowerMessage.includes('pain') || lowerMessage.includes('ache')) {
        return {
            response: "Pain management is important for your well-being:\n\n📍 Common types:\n• Acute pain (sudden, short-term)\n• Chronic pain (lasting 3+ months)\n• Neuropathic pain (nerve-related)\n• Inflammatory pain\n\n📊 Pain scale (0-10):\n• 0-3: Mild pain\n• 4-6: Moderate pain\n• 7-10: Severe pain\n\n💡 Management strategies:\n• Over-the-counter pain relievers\n• Heat/cold therapy\n• Gentle exercise\n• Relaxation techniques\n• Physical therapy\n\n⚠️ Seek medical attention for:\n• Severe or worsening pain\n• Pain with other concerning symptoms\n• Pain affecting daily activities",
            confidence: 0.8,
            followUp: "Can you describe the type and intensity of your pain?"
        };
    }
    
    // Default response for general health questions
    return {
        response: "I'm here to help with your health questions! I can assist with:\n\n🏥 Common topics:\n• Symptoms and conditions\n• Medication questions\n• Preventive care\n• Lifestyle recommendations\n• When to see a doctor\n\n💡 For the best medical advice:\n• I can provide general information\n• Always consult healthcare providers for specific concerns\n• Seek immediate care for emergencies\n• Keep your medical team informed\n\nHow can I help you today?",
        confidence: 0.7,
        followUp: "What specific health topic would you like to discuss?"
    };
}

module.exports = router;
